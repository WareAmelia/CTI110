"""
This is the Template Repl for Python with Turtle.

Python with Turtle lets you make graphics easily in Python.

Check out the official docs here: https://docs.python.org/3/library/turtle.html
"""

import turtle

def square():
    for _ in range(4):
        turtle.forward(100)
        turtle.right(90)
square()

turtle.left(90)

def triangle():
    for _ in range(3):
        turtle.forward(100)
        turtle.right(120)
triangle()