"""
This is the Template Repl for Python with Turtle.

Python with Turtle lets you make graphics easily in Python.

Check out the official docs here: https://docs.python.org/3/library/turtle.html
"""

import turtle
turtle.pensize(7)
turtle.colormode(255)
turtle.color(215, 100, 170)
turtle.left(75)
turtle.forward(75)
turtle.right(140)
turtle.forward(75)
turtle.back(40)
turtle.right(105)
turtle.forward(30)
turtle.back(30)
turtle.left(105)
turtle.forward(40)
turtle.penup()
turtle.left(80)
turtle.forward(15)
turtle.pendown()
turtle.left(90)
turtle.forward(75)
turtle.back(75)
turtle.right(40)
turtle.forward(43)
turtle.right(130)
turtle.forward(43)
turtle.left(145)
turtle.forward(75)